/*
  ResKeypad.h

  This file is part of resistive voltage divider keypad library (ResKeypad) for Arduino
  Uno/Pro/Leonardo/Mega 2560.
  
  ResKeypad was developed by Synapse(Hiroshi Tanigawa) in 2014.  This Library is
  originally distributed at Team Schaft's Homepage. 
  <http://www3.big.or.jp/~schaft/hardware/>

  ResKeypad is now under beta testing, so specification may be changed 
  in the future.

  ResKeypad is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation, either version 2.1 of the License, or
  (at your option) any later version.

  ResKeypad is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with ResKeypad.  If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef RESKEYPAD_H
#define RESKEYPAD_H

#include <avr/pgmspace.h>
#include <arduino.h>

#define RESKEYPAD_VERSION 100 // version 1.00

#define RESKEYPAD_RAM false // arrays are stored in RAM
#define RESKEYPAD_ROM true  // arrays are stored in ROM

// 4X4 keypad
PROGMEM const int RESKEYPAD_4X4[16]={17,59,110,170,236,306,384,465,549,633,713,787,855,914,964,1006}; // threshold levels for A/D conversion value
PROGMEM const char RESKEYPAD_4X4_SIDE_A[16]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; // characters assigned to SW1,SW2, ... , respectively
PROGMEM const char RESKEYPAD_4X4_SIDE_B[16]={'D','#','0','*','C','9','8','7','B','6','5','4','A','3','2','1'}; // characters assigned to SW1,SW2, ... , respectively
PROGMEM const int RESKEYPAD_4X5[20]={11,38,69,109,156,209,269,333,401,473,547,620,689,754,814,866,913,952,985,1012};  // threshold levels for A/D conversion value

class ResKeypad {
private:
  // variables
  const int aio; // analog input pin
  const byte KeyNum; // number of keys
  const int *threshold; // thresholds
  const char *KeyChar; // chars assigned to keys
  const boolean rom; // indicats if arrays are stored in ROM
  const int DebounceTime; // time in ms needed to fisnish bouncing
  unsigned long LastTime; // last time when key state changed
  signed char LastKey; // key pressed last (-1 when no key pressed)
  signed char LastValidKey; // key returned by GetKeyState function last
  boolean first; // intdicats if it is the first time to be read
#ifdef ARDUINO_ARCH_SAM
  int AdRes;
#endif

  
  // functions
  signed char DecodeKey(); 
  char KeyToChar(signed char key);
  
public:
  // constructor
  explicit ResKeypad(const int _aio, const byte _KeyNum, const int *_threshold, const char *_KeyChar=NULL, const boolean _rom=true, const int _DebounceTime=30);

  // functions
  signed char GetKeyState();
  char GetCharState() { return KeyToChar(GetKeyState()); };
  signed char GetKey();
  char GetChar() { return KeyToChar(GetKey()); };
  signed char WaitForKey();
  char WaitForChar() { return KeyToChar(WaitForKey()); };
#ifdef ARDUINO_ARCH_SAM
  int analogReadResolution(int res);
#endif
}; // ResKeypad

#endif // #ifndef RESKEYPAD_H