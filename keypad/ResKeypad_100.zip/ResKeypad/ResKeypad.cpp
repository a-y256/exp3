/*
  ResKeyPad.cpp

  This file is part of resistive voltage divider keypad library (ResKeypad) for Arduino
  Uno/Pro/Leonardo/Mega 2560.
  
  ResKeypad was developed by Synapse(Hiroshi Tanigawa) in 2014.  This Library is
  originally distributed at Team Schaft's Homepage. 
  <http://www3.big.or.jp/~schaft/hardware/>

  ResKeypad is now under beta testing, so specification may be changed 
  in the future.

  ResKeypad is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation, either version 2.1 of the License, or
  (at your option) any later version.

  ResKeypad is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with ResKeypad.  If not, see <http://www.gnu.org/licenses/>.

*/

#include "ResKeypad.h"

#if RESKEYPAD_VERSION != 100
#error versions of this file and header file are different.
#endif

// constructor
ResKeypad::ResKeypad(const int _aio, const byte _KeyNum, const int *_threshold, const char *_KeyChar, const boolean _rom, const int _DebounceTime) 
  : aio(_aio), KeyNum(_KeyNum), threshold(_threshold), KeyChar(_KeyChar), rom(_rom), DebounceTime(_DebounceTime), LastTime(0), LastKey(-1), LastValidKey(-1)
#ifdef ARDUINO_ARCH_SAM
    ,AdRes(10)
#endif
{
} // ResKeypad::ResKeypad

// converts key number into character code
char ResKeypad::KeyToChar(signed char key)
{
  if(key<0) return '\0';
  if(rom) {
    return pgm_read_byte_near(KeyChar+key);
  } else { 
    return KeyChar[key];
  }
} // ResKeypad::KeyToChar

// decodes key without debounce and char conversion
// returns 255 if no key is pressed
signed char ResKeypad::DecodeKey()
{
  byte i=0;

#ifdef ARDUINO_ARCH_SAM
  ::analogReadResolution(10);
#endif
  int n=analogRead(aio);
#ifdef ARDUINO_ARCH_SAM
  ::analogReadResolution(AdRes);
#endif
  while(i<KeyNum && n>(rom ? pgm_read_word_near(threshold+i) : threshold[i])) i++;
  if(i>=KeyNum) return -1;
  return i;
} // ResKeypad::DecodeKey

// returns pressed key with debounce processing
// returns -1 when no key pressed
signed char ResKeypad::GetKeyState()
{
  signed char CurrentKey=DecodeKey();
  
  if(CurrentKey!=LastKey) {
    LastKey=CurrentKey;
    LastTime=millis();
    return LastValidKey;
  } else { // CurrentKey==LastKey
    if(millis()-LastTime<DebounceTime || CurrentKey==LastValidKey) return LastValidKey;
    LastValidKey=CurrentKey;
    first=true;
    return CurrentKey;
  } // if
} // ResKeypad::GetKeyState

// returns pressed key only for the first time
// returns -1 when same key is read twice or more or when no key is pressed
signed char ResKeypad::GetKey()
{
  signed char key=GetKeyState();
  
  if(key>=0 && first) {
    first=false;
    return key;
  } // if
  return -1;
} // ResKeypad::GetKey()

signed char ResKeypad::WaitForKey()
{
  signed char key;
 
  while((key=GetKey())<0);
  return key;
} // ResKeypad::WaitForKey

#ifdef ARDUINO_ARCH_SAM
int ResKeypad::analogReadResolution(int res)
{
  if(res>0) {
    AdRes=res;
  } // if

  return AdRes;
} // ResKeypad::analogReadResolution
#endif
